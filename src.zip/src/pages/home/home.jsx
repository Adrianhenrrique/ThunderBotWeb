import { useState, useEffect } from 'react'
import Main from './components/main'

function Home() {

  return (
    <>
        <Main/>
    </>
  )
}

export default Home